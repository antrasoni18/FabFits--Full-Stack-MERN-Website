import React, { useRef, useEffect, useState } from 'react'
import { Helmet } from 'react-helmet';
import { Image } from '@chakra-ui/react'
import HashLoader from "react-spinners/HashLoader";
import './aboutcss.css'
const About = () => {
    const Line = useRef(null);
    const text = useRef(null);
    useEffect(() => {
        setTimeout(() => {
            Line.current.classList.add('lineon')
            text.current.classList.add('titleon');
        }, 5)


        return () => {

        }
    }, [])
    return (



        <>
            <Helmet>
                <title>About</title>
            </Helmet>


            <div className='headingA'>
                <div className='line' ref={Line}>
                </div>
                <h1 className='title' ref={text}>About Us</h1>
            </div>
            <div className='Content1'>
                <div className='text'>
                    <h1>
                        Why?
                    </h1>
                    <p>FabFits is a pioneering e-commerce platform designed to redefine the fashion shopping experience.
                        Seamlessly blending modern technology with the latest trends, FabFits offers a dynamic and personalized journey for fashion enthusiasts.
                        From cutting-edge AI features like voice and image search to immersive augmented reality try-ons, FabFits is more than an online store; it's a destination where style meets innovation.
                        Discover fashion like never before with FabFits – your gateway to a world where trends come to life.
                        The scope of the FabFits-E project is comprehensive and ambitious, aiming to create a cutting-edge fashion e-commerce platform that
                        leverages AI and AR technologies to provide an unparalleled shopping experience for users while meeting business and
                        technical objectives.
                        Proper project management and planning will be crucial to successfully execute the defined scope.</p>
                </div>

                <div className='imagecontainer'>
                    <div className='Imageabt'>
                        <Image className='mImage' boxSize='400px' objectFit="cover" src='https://images.unsplash.com/photo-1614771637369-ed94441a651a?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80' alt="Segun Adebayo" />
                    </div>
                </div>
            </div>
            <div className='Content2'>

                <div className='imagecontainer'>
                    <div className='Imageabt'>
                        <Image className='mImage' boxSize='400px' objectFit="cover" src='https://images.unsplash.com/photo-1614038276039-667c23bc32fa?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=389&q=80' alt="Segun Adebayo" />
                    </div>
                </div>
                <div className='text'>
                    <h1>
                        How?
                    </h1>
                    <p>
                        FabFits aims to revolutionize the fashion retail landscape by introducing innovative technologies and immersive experiences.
                        The primary objective is to provide users with a highly satisfying and personalized shopping experience through advanced features like AI-driven recommendations and AR-powered virtual try-ons.
                        Introduce augmented reality to allow users to virtually try on clothing items, bridging the gap between online and in-store shopping experiences.
                        Ensure a secure and seamless payment process by integrating a reliable payment gateway, instilling trust in users during their transactions on the platform.
                        Explore ways to contribute to sustainability efforts within the fashion industry, potentially reducing environmental impact through informed purchasing decisions and virtual try-ons.
                        Provide a platform for fashion brands and sellers to showcase their products to a wider audience, fostering business growth and collaboration.

                    </p>
                </div>
            </div>
        </>

    )
}

export default About
