import React, { useState, useEffect } from 'react';
import { Input, InputGroup, InputRightElement } from '@chakra-ui/input';
import { IoIosMic } from 'react-icons/io';
import { MdSearch } from 'react-icons/md';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

const Searchnav = ({ history }) => {
    const [keyword, setKeyword] = useState('');
    const { transcript, listening, resetTranscript } = useSpeechRecognition({
        recognitionOptions: { 
          continuous: true, // Continuous recognition
          interimResults: true, // Provide interim results
          autoStart: false // Don't start recognition automatically
        }
      });

      
console.log(transcript)

    useEffect(() => {
        if (!listening && transcript) {
            setKeyword(transcript);
            history.push(`/search/${encodeURIComponent(transcript)}`);
        }
    }, [listening, transcript, history]);

    const handleSearch = (e) => {
        if (keyword.trim() && e.which === 13) {
            history.push(`/search/${encodeURIComponent(keyword)}`);
        }
    };

    const handleMicClick = () => {
        if (listening) {
            SpeechRecognition.stopListening();
        } else {
            resetTranscript();
            SpeechRecognition.startListening({ continuous: false });
        }
    };



    return (
        <InputGroup>
            <Input
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                bgColor='white'
                placeholder='Search here ...'
                onKeyPress={handleSearch}
            />
            <InputRightElement>
                <IoIosMic
                    style={{ marginRight: '8px', cursor: 'pointer' }}
                    onClick={handleMicClick}
                    color={listening ? 'red' : 'black'}
                />
                <MdSearch onClick={() => history.push(`/search/${encodeURIComponent(keyword)}`)} style={{ cursor: 'pointer' }} />
            </InputRightElement>
        </InputGroup>
    );
};

export default Searchnav;