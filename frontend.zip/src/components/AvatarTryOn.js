import React from 'react'
import { AvatarCreator } from '@readyplayerme/react-avatar-creator';

export const AvatarTryOn = () => {
    return <AvatarCreator subdomain="demo" style={{ width: '100vw', height: '100vh', border: 'none', display:"flex", justifyContent:"center", alignItems:"center" }} />;
}
